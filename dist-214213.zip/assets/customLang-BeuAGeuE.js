import{a$ as s,b0 as a}from"./antdv-C1q31o1i.js";import"./vue-BkamnmIP.js";const e=Object.assign({}),c={message:{...s(e,"customLang"),antdLocale:a}};export{c as default};
