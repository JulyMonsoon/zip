const e=[{title:"参数名称",dataIndex:"configName",resizable:!0},{title:"参数键名",dataIndex:"configKey",resizable:!0,hideInSearch:!0}];export{e as columns};
