const e=[{field:"number",component:"InputNumber",label:"数量",required:!0,componentProps:{min:1},colProps:{span:24}}];export{e as baseSchemas};
