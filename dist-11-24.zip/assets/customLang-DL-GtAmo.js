import{a$ as s,b0 as a}from"./antdv-SHHrB1Kf.js";import"./vue-CAqWANk2.js";const e=Object.assign({}),c={message:{...s(e,"customLang"),antdLocale:a}};export{c as default};
