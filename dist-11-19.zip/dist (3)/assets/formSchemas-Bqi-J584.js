const e=[{field:"workmanshipName",component:"Input",label:"工序名称",required:!0,componentProps:{},colProps:{span:24}}];export{e as baseSchemas};
