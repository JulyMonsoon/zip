const e=[{title:"模板名称",dataIndex:"name",resizable:!0,hideInSearch:!0,width:200},{title:"模板内容",dataIndex:"content",resizable:!0,hideInSearch:!0}];export{e as columns};
