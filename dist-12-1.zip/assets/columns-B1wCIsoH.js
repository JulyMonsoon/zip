const e=[{title:"工序名称",dataIndex:"workmanshipName",resizable:!0}];export{e as columns};
