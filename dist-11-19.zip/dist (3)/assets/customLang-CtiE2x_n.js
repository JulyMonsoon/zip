import{a$ as s,b0 as a}from"./antdv-DDScm_9Q.js";import"./vue-B8gg3WaH.js";const e=Object.assign({}),c={message:{...s(e,"customLang"),antdLocale:a}};export{c as default};
